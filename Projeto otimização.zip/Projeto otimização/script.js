async function calcular() {

    const dados = {
        receita_acai:
        document.getElementById("receitaAcai").value,

        receita_mandioca:
        document.getElementById("receitaMandioca").value,

        custo_acai:
        document.getElementById("custoAcai").value,

        custo_mandioca:
        document.getElementById("custoMandioca").value,

        competencia:
        document.getElementById("competencia").value
    };

    const resposta = await fetch(
        "http://localhost:5000/calcular",
        {
            method:"POST",
            headers:{
                "Content-Type":"application/json"
            },
            body:JSON.stringify(dados)
        }
    );

    const resultado = await resposta.json();

    document.getElementById("resultado")
    .innerHTML = `
        <h2>Resultado</h2>

        <p>
            Produção ótima de Açaí:
            ${resultado.x}
        </p>

        <p>
            Produção ótima de Mandioca:
            ${resultado.y}
        </p>

        <p>
            Lucro Máximo:
            R$ ${resultado.lucro}
        </p>

        <p>
            Classificação:
            ${resultado.classificacao}
        </p>
    `;
}