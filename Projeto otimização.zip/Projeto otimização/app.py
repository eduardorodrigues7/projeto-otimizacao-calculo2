from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3

app = Flask(__name__)
CORS(app)

# ==========================
# Conexão com o banco
# ==========================
def conectar():
    return sqlite3.connect("database.db")


# ==========================
# Rota inicial
# ==========================
@app.route("/")
def home():
    return "API de Otimizacao Agricola funcionando!"


# ==========================
# Rota de cálculo
# ==========================
@app.route("/calcular", methods=["POST"])
def calcular():

    try:

        dados = request.json

        a = float(dados["receita_acai"])
        b = float(dados["receita_mandioca"])
        c = float(dados["custo_acai"])
        d = float(dados["custo_mandioca"])
        e = float(dados["competencia"])

        # Resolve o sistema
        det = (2 * c) * (2 * d) - (e ** 2)

        if det == 0:
            return jsonify({
                "erro": "Sistema sem solução única."
            }), 400

        x = ((a * (2 * d)) - (b * e)) / det
        y = (((2 * c) * b) - (a * e)) / det

        lucro = (
            a * x
            + b * y
            - c * (x ** 2)
            - d * (y ** 2)
            - e * x * y
        )

        # Hessiana
        h11 = -2 * c
        h22 = -2 * d

        determinante_hessiana = (h11 * h22) - (e ** 2)

        if determinante_hessiana > 0 and h11 < 0:
            classificacao = "Máximo"
        elif determinante_hessiana > 0 and h11 > 0:
            classificacao = "Mínimo"
        else:
            classificacao = "Ponto de Sela"

        # Salvar no banco
        conn = conectar()

        conn.execute("""
        INSERT INTO consultas (
            receita_acai,
            receita_mandioca,
            custo_acai,
            custo_mandioca,
            competencia,
            x_otimo,
            y_otimo,
            lucro,
            classificacao
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            a,
            b,
            c,
            d,
            e,
            x,
            y,
            lucro,
            classificacao
        ))

        conn.commit()
        conn.close()

        return jsonify({
            "x": round(x, 2),
            "y": round(y, 2),
            "lucro": round(lucro, 2),
            "classificacao": classificacao
        })

    except Exception as erro:
        return jsonify({
            "erro": str(erro)
        }), 500


# ==========================
# Executar aplicação
# ==========================
if __name__ == "__main__":
    app.run(debug=True)